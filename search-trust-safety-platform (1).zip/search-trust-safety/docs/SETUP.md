# Setup Guide

## Prerequisites
- Python 3.9+
- pip

## Installation

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/search-trust-safety.git
cd search-trust-safety

# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate       # Mac/Linux
venv\Scripts\activate          # Windows

# Install dependencies
pip install -r requirements.txt
```

## Running the Pipeline

### Without LLM (no API key needed)
```bash
python run_pipeline.py --skip-llm
```

### With LLM policy evaluation
```bash
cp .env.example .env
# Edit .env and add your Anthropic API key

export ANTHROPIC_API_KEY=your_key_here
python run_pipeline.py
```

### Launch Dashboard
```bash
streamlit run dashboard/app.py
```

### Run Tests
```bash
pytest tests/ -v
```

## Project Structure
```
search-trust-safety/
├── data/               # Dataset generation
├── src/
│   ├── classifiers/    # ML abuse detector (XGBoost + SHAP)
│   ├── llm_eval/       # LLM policy classifier (Claude API)
│   └── metrics/        # KPI framework + alert engine
├── dashboard/          # Streamlit dashboard
├── models/             # Saved model artifacts (git-ignored)
├── tests/              # Pytest suite
└── run_pipeline.py     # End-to-end runner
```
